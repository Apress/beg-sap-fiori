import requests
import json
import sched, time
import RPi.GPIO as GPIO
import os
from StringIO import StringIO
from parse import *
sTimer = sched.scheduler(time.time, time.sleep)
LedPin = 11
GPIO.setmode(GPIO.BOARD)
GPIO.setup(LedPin, GPIO.OUT)
def fetch_command(command):
	url ='https://sp1134263trial.hanatrial.ondemand.com/persistence-with-jpa/?action=GetCurrentReading&Raspberrydevice=LED';
	r = requests.get(url)
	js = r.json()
        result = js['result']
	Switch = result['reading1']

        if Switch == 'HIGH':
              GPIO.output(LedPin, GPIO.HIGH)
        elif Switch== 'LOW':
              GPIO.output(LedPin, GPIO.LOW)
        else:
              GPIO.output(LedPin, GPIO.HIGH)
        print(Switch)
        command.enter(1, 1, fetch_command, (command,))

sTimer.enter(1, 1, fetch_command, (sTimer,))
sTimer.run()