import requests
import json
import sched, time
import RPi.GPIO as GPIO
import os
from StringIO import StringIO
from parse import *
from w1thermsensor import W1ThermSensor

sTimer = sched.scheduler(time.time, time.sleep)
sensor = W1ThermSensor()
def fetch_command(command):
	temperature_in_celsius = sensor.get_temperature()
	temperature_in_fahrenheit = sensor.get_temperature(W1ThermSensor.DEGREES_F)
	temperature_in_kelvin = sensor.get_temperature(W1ThermSensor.KELVIN)
	temperature_in_all_units = sensor.get_temperatures([W1ThermSensor.DEGREES_C, W1ThermSensor.DEGREES_F, W1ThermSensor.KELVIN])
	url ='https://sp1134263trial.hanatrial.ondemand.com/persistence-with-jpa/?action=GetCurrentReading&Raspberrydevice=LED';
	r = requests.get(url)
	js = r.json()
        result = js['result']
	Switch = result['reading2']
	if Switch == 'ON':
		url ='https://sp1134263trial.hanatrial.ondemand.com/persistence-with-jpa/?action=CreateReading&Raspberrydevice=THERMOMETER&Reading1='+str(temperature_in_celsius)+'&Reading2='+str(temperature_in_fahrenheit)+'&Reading3='+str(temperature_in_kelvin);
		requests.get(url)
		print(temperature_in_all_units)
        command.enter(1, 1, fetch_command, (command,))

sTimer.enter(1, 1, fetch_command, (sTimer,))
sTimer.run()