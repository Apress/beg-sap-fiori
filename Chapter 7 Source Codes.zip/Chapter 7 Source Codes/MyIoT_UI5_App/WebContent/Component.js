jQuery.sap.declare("com.iotApp.Component");

sap.ui.core.UIComponent.extend("com.iotApp.Component", {

	metadata: {
		"abstract": true,
		version : "1.0",
		includes : [ 
		             "styles/style.css"             
		            ],

		routing: {

			config: {
				viewType: "XML",
				viewPath: "com.iotApp.view",
				clearTarget: false,
				transition: "slide"
			},

			routes: [
				{
					pattern: "",
					name: "default",
					view: "Home",	
					targetControl: "App",
					targetAggregation: "pages",
						subroutes : 
							  [
								     {
									pattern: "temperature",
									name: "Temperature",
									view: "Temperature",
									targetAggregation: "pages"
								       },
								       {
											pattern: "allreadings",
											name: "AllReadings",
											view: "AllReadings",
											targetAggregation: "pages"
										       }
						      ]
				},
		         
	        ]

		}

	},

	init: function() {
//		jQuery.sap.require("com.wfm.js.d3");                // you can call js library files like this also, but now we can do the same in the Metadata structure
//		jQuery.sap.require("com.wfm.js.liquidFillGuage");  
//		jQuery.sap.require("com.wfm.js.radialProgress");
//		jQuery.sap.require("com.wfm.controls.progress");
//		jQuery.sap.require("com.wfm.controls.liquidGuage")

		jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
		jQuery.sap.require("sap.ui.core.routing.HashChanger");

		//call createContent
		sap.ui.core.UIComponent.prototype.init.apply(this, arguments);

		this._router = this.getRouter();

		//initlialize the router
		this._routeHandler = new sap.m.routing.RouteMatchedHandler(this._router);
		this._router.initialize();

	},

	createContent: function() {

		var oView = sap.ui.view({
			id: "App",
			viewName: "com.iotApp.view.App",
			type: "XML",
			viewData: {
				component: this
			}
		});
		sap.ui.getCore().HANA = new Object();
		//Make sure you update the below URL before running your application
		sap.ui.getCore().HANA.URL = "https://<Your Java Persistance Application Name><Your Hana Trial Account Name>.hanatrial.ondemand.com/persistence-with-jpa";
        var url = sap.ui.getCore().HANA.URL;
		var oModel = new sap.ui.model.json.JSONModel();
		var oModelData =  this.loadModel(url);
		oView.setModel(oModelData);
//		var LEDStat = this.loadModel(url1);
//		oView.setModel(LEDStat,"LEDStatus");
//		var oModel = new sap.ui.model.json.JSONModel('model/mock.json');
//		oView.setModel(oModel);

		// set i18n model
		var i18nModel = new sap.ui.model.resource.ResourceModel({
			bundleUrl: "i18n/i18n.properties"
		});
		oView.setModel(i18nModel, "i18n");

		var deviceModel = new sap.ui.model.json.JSONModel({
			isPhone: sap.ui.Device.system.phone,
			listMode: (sap.ui.Device.system.phone) ? "None" : "SingleSelectMaster",
			listItemType: (sap.ui.Device.system.phone) ? "Active" : "Inactive"
		});

		deviceModel.setDefaultBindingMode("OneWay");
		oView.setModel(deviceModel, "device");
		return oView;

	},
	loadModel: function(url) {
        var url = url;
        var oModel = new sap.ui.model.json.JSONModel();
        oModel.loadData(url, null, false);
        return oModel;
    }
})