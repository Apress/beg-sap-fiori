jQuery.sap.require("com.iotApp.util.Formatter");
jQuery.sap.require("sap.m.MessageToast")
sap.ui.controller("com.iotApp.view.Home", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.Home
*/
	onInit: function() {
		this.checkSensorStatus("LED");
		this.checkSensorStatus("THERMOMETER");
		var internalJson = new sap.ui.model.json.JSONModel({
			icon:"sap-icon://lightbulb"
	});
	this.getView().setModel(internalJson,"Sensors");
	},
	// This function is to check the Sensor status initially and set the text of the ObjectListItem control accordingly
	checkSensorStatus: function(deviceID){
		var URL;
		var statusModel;
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.url = sap.ui.getCore().HANA.URL;
		if(deviceID==="LED"){
			var oLed= this.getView().byId("LEDSwitch");
			URL = this.url+ "/?action=GetCurrentReading&Raspberrydevice=LED";
			statusModel = this.checkStatus(URL);
			if(statusModel.oData["result"])
			{
				var LEDStat = statusModel.oData["result"].reading1;
				if (LEDStat ==="LOW"){
					oLed.setNumber("ON");
				}
				else{
					oLed.setNumber("OFF");
				}
			}
		}
		else if(deviceID==="THERMOMETER"){
			URL = this.url+ "/?action=GetCurrentReading&Raspberrydevice=THERMOMETER";
			statusModel = this.checkStatus(URL);
			if(statusModel.oData["result"])
			{
			var Temperature = statusModel.oData["result"].reading1;
			Temperature = Temperature + " °C ";
			var oTemp= this.getView().byId("Temperature");
			this.refreshInterval = 2000;
			oTemp.setNumber(Temperature);
			}
		}
		
	},
	//This is the event listener of the LED Object List item to switch the LED ON/OFF based on user Input
	onSwitch: function(oEvent){
		var oBtn = this.getView().byId("LED");
		var oLed= this.getView().byId("LEDSwitch");
		
		var statusModel = this.checkStatus(this.url + "/?action=GetCurrentReading&Raspberrydevice=LED");
		if(statusModel.oData["result"])
			{
		var LEDStat = statusModel.oData["result"].reading1;
//		var LEDStat = result.oData["result"].reading1;
		var oModel = new sap.ui.model.json.JSONModel();
		if (LEDStat ==="LOW"){
		var result1 = oModel.loadData(this.url +  "/?action=CreateReading&Raspberrydevice=LED&Reading1=HIGH&Reading2=OFF&Reading3=ON");
		var msg = 'Light Switched Off';
		oLed.setNumber("OFF");
	    sap.m.MessageToast.show(msg);
		}
		else if(LEDStat ==="HIGH"){
		var result1 = oModel.loadData(this.url + "/?action=CreateReading&Raspberrydevice=LED&Reading1=LOW&Reading2=OFF&Reading3=ON");
		var msg = 'Light Switched On';
		oLed.setNumber("ON");
	    sap.m.MessageToast.show(msg);
		}
		else{
			var result1 = oModel.loadData( this.url + "/?action=CreateReading&Raspberrydevice=LED&Reading1=HIGH&Reading2=OFF&Reading3=ON");	
			var msg = 'Light Switched Off';
			oLed.setNumber("OFF");
		    sap.m.MessageToast.show(msg);
		}
			}
//		$.ajax({
//			Url:"https://<Your Java Persistance Application Name><Your Hana Trial Account Name>.hanatrial.ondemand.com/persistence-with-jpa/?action=CreateReading&Raspberrydevice=LED&Reading1=LOW",
//			type: "GET",
//			Datatype:"json",
//			Contenttype:"text/xml;charset=\"utf-8\"",
//			 success: function(data, textStatus, jqXHR) { // callback called when data is received
////			         alert("success");     // fill the received data into the JSONModel
//			    },
//		     error: function(){alert("error");}
//		});
	},
	//This method triggers a powerOn command in the Raspberry Pi OS
	onPowerOn: function(){
		var oModel = new sap.ui.model.json.JSONModel();
		var result1 = oModel.loadData(this.url + "/?action=CreateReading&Raspberrydevice=LED&Reading1=HIGH&Reading2=OFF&Reading3=ON");	
		var msg = 'Raspberry Is Online';
	    sap.m.MessageToast.show(msg);	
	},
	// This method triggers a shutdown command in the Raspberry Pi OS. 
	// Once you click on the Shutdown button, make sure you click the powerOn button before switching on the Raspberry Pi, else on starting the python script for systemPower, it will shutdown the raspberry Pi.
	onShutDown: function(){
		var oModel = new sap.ui.model.json.JSONModel();
		var result1 = oModel.loadData(this.url + "/?action=CreateReading&Raspberrydevice=LED&Reading1=HIGH&Reading2=OFF&Reading3=OFF");	
		var msg = 'Raspberry Shutting Down';
	    sap.m.MessageToast.show(msg);			
	},
	//This method makes a call to the HANA Cloud JAVA application based on the appropriate Action set in the URL  while its being called.
	checkStatus: function(url) {
        var url = url;
        var oModel = new sap.ui.model.json.JSONModel();
        oModel.loadData(url, null, false);
        return oModel;
    },
    
  //This is the event listener to refresh the current Thermometer Reading
	onTherm: function(oEvent){
		var statusModel = this.checkStatus(this.url +  "/?action=GetCurrentReading&Raspberrydevice=THERMOMETER");
		var Temperature = statusModel.oData["result"].reading1
		Temperature = Temperature + " °C "
		var oTemp= this.getView().byId("Temperature");
		oTemp.setNumber(Temperature);	
		
	},
	//This is the event listener to activate the Thermometer sensor 
    onThermometerActivate: function(oEvent){
		this.temp;
		var statusModel = this.checkStatus(this.url + "/?action=GetCurrentReading&Raspberrydevice=LED");
		var LEDStat = statusModel.oData["result"].reading1
		this.temp = statusModel.oData["result"].reading2
	      if (this.temp === "ON"){
				var deactivateThermometer = this.checkStatus(this.url + "/?action=CreateReading&Raspberrydevice=LED&Reading1="+LEDStat +"&Reading2=OFF&Reading3=ON");
				oEvent.getSource().setPressed(false);
				var msg = 'Thermometer Deactivated';
			    sap.m.MessageToast.show(msg);
	      }
	      else
	    	  {
	    	  var activateThermometer = this.checkStatus(this.url + "/?action=CreateReading&Raspberrydevice=LED&Reading1="+LEDStat +"&Reading2=ON&Reading3=ON");
	    	  oEvent.getSource().setPressed(true);
	    	  var msg = 'Thermometer Activated';
			    sap.m.MessageToast.show(msg);
	    	  }
    },
  //This method will navigate to the AllReadings View which shows the latest 50 records in the HANA Cloud DB as a list item control
	onAllReadings: function(oEvent){
		this.router.navTo("AllReadings");
	}
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.Home
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.Home
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.Home
*/
//	onExit: function() {
//
//	}

});