jQuery.sap.require("com.iotApp.util.Formatter");
sap.ui.controller("com.iotApp.view.AllReadings", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.AllReadings
*/
	onInit: function() {
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.attachRoutePatternMatched(this._handleRouteMatched, this);
		this.url = sap.ui.getCore().HANA.URL;
		var oModel = new sap.ui.model.json.JSONModel();
		var oModelData =  this.loadModel(this.url);
		this.getView().setModel(oModelData);
		
	},
	_handleRouteMatched: function(evt) {
//		this.empIndex = evt.getParameter("arguments").data;
//
//		var context = sap.ui.getCore().byId("App").getModel().getContext('/entityname/' + this.empIndex);
//
//		this.getView().setBindingContext(context);
	},
backToHome: function(){
		this.router.navTo("default");
	},
	handleLiveChange: function(evt) {

		// create model filter
		var filters = [];
		var sQuery = evt.getParameters().newValue;
		if (sQuery && sQuery.length > 0) {
			var filter = new sap.ui.model.Filter("raspberrydevice", sap.ui.model.FilterOperator.Contains, sQuery);
			filters.push(filter);
		}

		// update list binding
		var list = this.getView().byId("list");
		var binding = list.getBinding("items");
		binding.filter(filters);
	},
	loadModel: function(url) {
        var url = url;
        var oModel = new sap.ui.model.json.JSONModel();
        oModel.loadData(url, null, false);
        return oModel;
    }
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.AllReadings
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.AllReadings
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.AllReadings
*/
//	onExit: function() {
//
//	}

});