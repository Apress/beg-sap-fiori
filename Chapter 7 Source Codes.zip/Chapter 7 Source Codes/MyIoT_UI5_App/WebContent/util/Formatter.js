sap.ui.define(function() {
	"use strict";

	var Formatter = {
	
		categoryIcon : function (sValue) {
			var sIcon;
			switch (sValue) {
			case "LED":
				sIcon = "sap-icon://projector";
				break;
			case "TEMP":
				sIcon = "sap-icon://measure";
				break;
			case "Accessory":
				sIcon = "sap-icon://widgets";
				break;
			case "Printer":
				sIcon = "sap-icon://print";
				break;
			case "Monitor":
				sIcon = "sap-icon://sys-monitor";
				break;
			case "Laptop":
				sIcon = "sap-icon://laptop";
				break;
			case "Keyboard":
				sIcon = "sap-icon://collections-management";
				break;
			default:
				sIcon = "sap-icon://product";
			}
			return sIcon;
		},
	deviceIconStatus: function(value) {
		if (value === "HIGH") {
			return sap.ui.core.ValueState.Error;
		}
		if (value === "LOW") {
			return sap.ui.core.ValueState.Success;
		} else {
			return sap.ui.core.ValueState.Success;
		}
	},
   deviceIcon: function(value){
	   if (value === "LED") {
		   value = "sap-icon://lightbulb";
		}
	   else if (value === "THERMOMETER") {
			value = "sap-icon://temperature";
		}
	   else 
	   {
			value = "sap-icon://sys-monitor";
		}  
		return value;
   },
deviceText: function(value){
		if (value === "HIGH") {
			return value;
			}
		else if (value === "LOW") {
				return value;
			} 
		else if (value ===""){
			return value;
		}
		else if (value === null){
			return value;
		}
		else 
		{
				value = value + " " + "°C";
				return value;
			}  
				
	},
   deviceTextF: function(value){
		if (value === "HIGH") {
			return value;
			}
		else if (value === "LOW") {
				return value;
			} 
		else if (value ===""){
			return value;
		}
		else if (value === null){
			return value;
		}
		else 
		{
				value = value + " " + "Fahrenheit";
				return value;
			}  
				
	},
	   deviceTextK: function(value){
			if (value === "HIGH") {
				return value;
				}
			else if (value === "LOW") {
					return value;
				} 
			else if (value ===""){
				return value;
			}
			else if (value === null){
				return value;
			}
			else 
			{
					value = value + " " + "Kelvin";
					return value;
				}  
					
		}
	};

	return Formatter;

}, /* bExport= */ true);