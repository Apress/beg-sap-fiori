package com.sap.cloud.sample.persistence;

import java.io.IOException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.sap.security.core.server.csi.IXSSEncoder;
import com.sap.security.core.server.csi.XSSEncoder;

/**
 * Servlet implementing a simple JPA based persistence sample application for SAP HANA Cloud Platform.
 */
public class PersistenceWithJPAServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = LoggerFactory.getLogger(PersistenceWithJPAServlet.class);

    private DataSource ds;
    private EntityManagerFactory emf;

    /** {@inheritDoc} */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public void init() throws ServletException {
        Connection connection = null;
        try {
            InitialContext ctx = new InitialContext();
            ds = (DataSource) ctx.lookup("java:comp/env/jdbc/DefaultDB");

            Map properties = new HashMap();
            properties.put(PersistenceUnitProperties.NON_JTA_DATASOURCE, ds);
            emf = Persistence.createEntityManagerFactory("persistence-with-jpa", properties);
        } catch (NamingException e) {
            throw new ServletException(e);
        }
    }

    /** {@inheritDoc} */
    @Override
    public void destroy() {
        emf.close();
    }

    /** {@inheritDoc} */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String method = convertToUTF(request.getParameter("action"));
    	
    	
    	   if (method != null && method.equalsIgnoreCase("AllReadings")) {
			
			List<Raspberry> allReadings = getAllReadings();
			convertAllReadingsToJsonFormat(response, allReadings);
			
		   }
    		if (method != null && method.equalsIgnoreCase("CreateReading")) {
//    			response.getWriter().println("Transmitted Method: " + method);
    			Raspberry  raspberryData = getReadingsFromIncomingRequests(request);
//    			response.getWriter().println("Captured Value: " + raspberryData.getRaspberrydevice());
    			CreateReadings(raspberryData);
    			
    		}
    		if (method != null && method.equalsIgnoreCase("GetCurrentReading")) {
//    			response.getWriter().println("Transmitted Method: " + method);
    			Raspberry  raspberryData = getReadingsFromIncomingRequests(request);
    			List<Raspberry> CurrentReadings = getCurrentReadings(raspberryData.getRaspberrydevice());
    			convertCurrentReadingsToJsonFormat(response, CurrentReadings);
    		}
    		if (method != null && method.equalsIgnoreCase("GetSpecificReadings")) {
//    			response.getWriter().println("Transmitted Method: " + method);
    			Raspberry  raspberryData = getReadingsFromIncomingRequests(request);
    			List<Raspberry> SpecificReadings = getCurrentReadings(raspberryData.getRaspberrydevice());
    			convertCurrentReadingsToJsonFormat(response, SpecificReadings);
    		}    		
           if (method != null && method.equalsIgnoreCase("ShowUI")) {
    			
             response.getWriter().println("<p>Internet Of Things</p>");
             try {
            	 appendAddForm(response);
                 appendRaspberryTable(response);
             } catch (Exception e) {
                 response.getWriter().println("Table fetch failed with reason: " + e.getMessage());
                 LOGGER.error("Table fetch failed", e);
             }
    		}
           if (method==null){
        	List<Raspberry> allReadings = getAllReadings();
   			convertAllReadingsToJsonFormat(response, allReadings);
           }

    }

    /** {@inheritDoc} */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException {
        try {
            doAdd(request);
            doGet(request, response);
        } catch (Exception e) {
            response.getWriter().println("Table data creation failed with reason: " + e.getMessage());
            LOGGER.error("Table data creation failed", e);
        }
    }

    private void appendRaspberryTable(HttpServletResponse response) throws SQLException, IOException {
        // Append table that lists all Readings
        EntityManager em = emf.createEntityManager();
        try {
            @SuppressWarnings("unchecked")
            List<Raspberry> resultList = em.createNamedQuery("AllReadings").getResultList();
            response.getWriter().println(
                    "<p><table border=\"1\"><tr><th colspan=\"6\">"
                            + (resultList.isEmpty() ? "" : resultList.size() + " ")
                            + "Entries in the Database</th></tr>");
            if (resultList.isEmpty()) {
                response.getWriter().println("<tr><td colspan=\"6\">Database is empty</td></tr>");
            } else {
                response.getWriter().println("<tr><th>Id</th><th>Raspberrydevice</th><th>Reading1</th><th>Reading2</th><th>Reading3</th><th>UniqueDeviceID</th><th>UpdatedOn</th></tr>");
            }
            IXSSEncoder xssEncoder = XSSEncoder.getInstance();
            for (Raspberry p : resultList) {
                response.getWriter().println(
                        "<tr><td>" + p.getId() + "</td><td>" + xssEncoder.encodeHTML(p.getRaspberrydevice()) + "</td><td>"
                                + xssEncoder.encodeHTML(p.getReading1()) + "</td><td>"+ xssEncoder.encodeHTML(p.getReading2()) + "</td><td>" + xssEncoder.encodeHTML(p.getReading3()) + "</td><td>"+p.getUniqueDeviceID()+"</td><td>"+p.getUpdatedOn()+"</td></tr>");
            }
            response.getWriter().println("</table></p>");
        } finally {
            em.close();
        }
    }

    private void appendAddForm(HttpServletResponse response) throws IOException {
        // Append form through which new Reading can be added
        response.getWriter().println(
                "<p><form action=\"\" method=\"post\">" + "Raspberrydevice:<input type=\"text\" name=\"Raspberrydevice\">"
                        + "&nbsp;Reading1:<input type=\"text\" name=\"Reading1\">"
                        + "&nbsp;Reading2:<input type=\"text\" name=\"Reading2\">"
                        + "&nbsp;Reading3:<input type=\"text\" name=\"Reading3\">"
                        + "&nbsp;UniqueDeviceID:<input type=\"text\" name=\"UniqueDeviceID\">"
                        + "&nbsp;<input type=\"submit\" value=\"Add Readings\">" + "</form></p>");
    }

	private String convertToUTF(String text) {

		String result = null;
		if (text != null && text.length() > 0) {
			IXSSEncoder xssEncoder = XSSEncoder.getInstance();

			try {
				result = (String) xssEncoder.encodeURL(text).toString();
				result = URLDecoder.decode(result, "UTF-8");
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return result;
	}
private Raspberry getReadingsFromIncomingRequests(HttpServletRequest request) {
		Raspberry raspberryData = new Raspberry();
		String raspberryDevice = convertToUTF(request.getParameter("Raspberrydevice"));
		raspberryData.setRaspberrydevice(raspberryDevice);
		raspberryData.setReading1(convertToUTF(request.getParameter("Reading1")));
		raspberryData.setReading2(convertToUTF(request.getParameter("Reading2")));
		raspberryData.setReading3(convertToUTF(request.getParameter("Reading3")));
		raspberryData.setUniqueDeviceID(convertToUTF(request.getParameter("UniqueDeviceID")));
		raspberryData.setUpdatedOn(new Timestamp(new Date().getTime()));
		return raspberryData;
	}
@SuppressWarnings("unchecked")
public List<Raspberry> getAllReadings() {
	List<Raspberry> result = null;

	EntityManager em = emf.createEntityManager();
	try {
		Query q = em.createNamedQuery("AllReadings");
		q.setMaxResults(50);
		result = q.getResultList();

	} catch (Exception e) {

	}

	em.close();
	return result;
}
@SuppressWarnings("unchecked")
public List<Raspberry> getCurrentReadings(String raspberryDevice) {
	List<Raspberry> result = null;
//	response.getWriter().println("Captured Value: " + raspberryData.getRaspberrydevice());
	EntityManager em = emf.createEntityManager();
	try {
		Query q = em.createNamedQuery("CurrentReading");
		q.setParameter("valueRaspberrydevice", raspberryDevice);
//		q.setParameter("valueRaspberrydevice", raspberryData.getRaspberrydevice());
//		q.setMaxResults(500);
		result = q.getResultList();

	} catch (Exception e) {

	}

	em.close();
	return result;
}
@SuppressWarnings("unchecked")
public List<Raspberry> getSpecificReadings(String raspberryDevice) {
	List<Raspberry> result = null;
//	response.getWriter().println("Captured Value: " + raspberryData.getRaspberrydevice());
	EntityManager em = emf.createEntityManager();
	try {
		Query q = em.createNamedQuery("SpecificReadings");
		q.setParameter("valueRaspberrydevice", raspberryDevice);
//		q.setParameter("valueRaspberrydevice", raspberryData.getRaspberrydevice());
		q.setMaxResults(500);
		result = q.getResultList();

	} catch (Exception e) {

	}

	em.close();
	return result;
}
private void convertAllReadingsToJsonFormat(HttpServletResponse response, List<Raspberry> allReadings) {
	Gson gson = new Gson();
	try {
		response.getWriter().println("{");
		response.getWriter().println('"' + "reading" + '"' + ":[");
		for (int i = 0; i < allReadings.size(); i++) {
//			response.getWriter().println('"' + "reading" + i + '"' + ":");
			response.getWriter().println(gson.toJson(allReadings.get(i)));

			if (i != allReadings.size() - 1) {
				response.getWriter().println(",");
			}
		}

		response.getWriter().println("]}");
	} catch (IOException e) {
		e.printStackTrace();
	}

}
private void convertCurrentReadingsToJsonFormat(HttpServletResponse response, List<Raspberry> CurrentReadings){
	Gson gson = new Gson();
//	System.out.println("ERROR: persisting measurement didn't work " + e.getMessage());
	try {
		response.getWriter().println("{");
		response.getWriter().println('"' + "result" + '"' + ":");
		for (int i = 0; i < CurrentReadings.size(); i++) {
//			response.getWriter().println('"' + "reading" + i + '"' + ":");;
			response.getWriter().println(gson.toJson(CurrentReadings.get(i)));

			if (i != CurrentReadings.size() - 1) {
				response.getWriter().println(",");
			}
		}

//		response.getWriter().println("]}");
		response.getWriter().println("}");
	} catch (IOException e) {
		e.printStackTrace();
	}	
}
private void convertSpecificReadingsToJsonFormat(HttpServletResponse response, List<Raspberry> SpecificReadings){
	Gson gson = new Gson();
//	System.out.println("ERROR: persisting measurement didn't work " + e.getMessage());
	try {
		response.getWriter().println("{");
		response.getWriter().println('"' + "result" + '"' + ":");
		for (int i = 0; i < SpecificReadings.size(); i++) {
//			response.getWriter().println('"' + "reading" + i + '"' + ":");;
			response.getWriter().println(gson.toJson(SpecificReadings.get(i)));

			if (i != SpecificReadings.size() - 1) {
				response.getWriter().println(",");
			}
		}

//		response.getWriter().println("]}");
		response.getWriter().println("}");
	} catch (IOException e) {
		e.printStackTrace();
	}	
}
public boolean CreateReadings( Raspberry raspberryData) {
	boolean result = false;

	EntityManager em = emf.createEntityManager();
	// System.out.println("Trying to commit sensor data for sensor " +
	// measurement.getSensorDescription());
	try {
		if (raspberryData != null && raspberryData.getRaspberrydevice() != null) {
			em.getTransaction().begin();
			em.persist(raspberryData);
			em.getTransaction().commit();
		}
	} catch (Exception e) {
		System.out.println("Unable to record readings " + e.getMessage());
	} finally {
		em.close();
	}

	return result;
}
    private void doAdd(HttpServletRequest request) throws ServletException, IOException, SQLException {
        // Extract RaspBerry Device Name to be added from request
        String Raspberrydevice = request.getParameter("Raspberrydevice");
        String Reading1 = request.getParameter("Reading1");
        String Reading2 = request.getParameter("Reading2");
        String Reading3 = request.getParameter("Reading3");
        String UniqueDeviceID = request.getParameter("UniqueDeviceID");
//        Timestamp UpdatedOn = request.getParameter("UpdatedOn");

        // Add Reading if Raspberrydevice and Reading1 is not null/empty
        EntityManager em = emf.createEntityManager();
        try {
            if (Raspberrydevice != null && Reading1 != null && !Raspberrydevice.trim().isEmpty() && !Reading1.trim().isEmpty()) {
                Raspberry Raspberry = new Raspberry();
                Raspberry.setRaspberrydevice(Raspberrydevice);
                Raspberry.setReading1(Reading1);
                Raspberry.setReading2(Reading2);
                Raspberry.setReading3(Reading3);
                Raspberry.setUniqueDeviceID(UniqueDeviceID);
                Raspberry.setUpdatedOn(new Timestamp(new Date().getTime()));
                em.getTransaction().begin();
                em.persist(Raspberry);
                em.getTransaction().commit();
            }
        } finally {
            em.close();
        }
    }
    
}
