package com.sap.cloud.sample.persistence;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * 
 */
@Entity
@Table(name = "RaspberryTable")
@NamedQueries({
@NamedQuery(name = "AllReadings", query = "select p from Raspberry p ORDER BY p.id DESC"),
@NamedQuery(name = "SpecificReadings", query = "select p from Raspberry p where p.raspberrydevice = :valueRaspberrydevice"),
@NamedQuery(name = "CurrentReading", query = "select p from Raspberry p where p.raspberrydevice = :valueRaspberrydevice and p.id =  (SELECT MAX(v.id) from Raspberry v where v.raspberrydevice = :valueRaspberrydevice)")
})
//@NamedQuery(name = "UpdateReading", query = "Update Raspberry p set p.reading1 = :valueReading1 where p.raspberrydevice = :valueRaspberrydevice "),
//@NamedQuery(name = "SpecificReading", query = "select p from Raspberry p  where p.raspberrydevice = :valueRaspberrydevice "),
//@NamedQuery(name = "CurrentReading",query = "select p from Raspberry p where p.raspberrydevice = :valueRaspberrydevice and p.updatedOn =  (SELECT MAX(v.updatedOn) from Raspberry v where v.raspberrydevice = :valueRaspberrydevice)")
public class Raspberry {
    @Id
    @GeneratedValue
    private long id;
    @Basic
    private String raspberrydevice;
    @Basic
    private String reading1;
    @Basic
    private String reading2;
    @Basic
    private String reading3;
    @Basic
    private String uniqueDeviceID;
    @Basic
    private Timestamp updatedOn;
    
    public long getId() {
        return id;
    }

    public void setId(long newId) {
        this.id = newId;
    }

    public String getRaspberrydevice() {
        return this.raspberrydevice;
    }

    public void setRaspberrydevice(String value) {
        this.raspberrydevice = value;
    }

    public String getReading1() {
        return this.reading1;
    }

    public void setReading1(String newReading1) {
        this.reading1 = newReading1;
    }
    public String getReading2() {
        return this.reading2;
    }

    public void setReading2(String newReading2) {
        this.reading2 = newReading2;
    }
    public String getReading3() {
        return this.reading3;
    }

    public void setReading3(String newReading3) {
        this.reading3 = newReading3;
    }
    public String getUniqueDeviceID() {
        return this.uniqueDeviceID;
    }

    public void setUniqueDeviceID(String newuniqueDeviceID) {
        this.uniqueDeviceID = newuniqueDeviceID;
    }
    public Timestamp getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Timestamp newUpdatedOn) {
        this.updatedOn = newUpdatedOn;
    }
}
