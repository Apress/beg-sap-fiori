var barcode_val;
var barcode_result;
var image;
var map;
var od;
jQuery.sap.require("sap.m.MessageToast");
sap.ui.controller("sap.ui.Cordova.app.view.Barcode", {

	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf view.Barcode
	 */
	onInit: function() {
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		barcode_val = this.getView().byId("barcode_val");
		mat_val = this.getView().byId("material_val");
		desc_val = this.getView().byId("description_val");
		crt_val = this.getView().byId("crt_on_val");
		image = this.getView().byId("image_url");
		img = this.getView().byId("img");
	},
	handle_upload: function() {

	},
	handle_gallery: function() {

	},
	handle_location: function() {
		//		debugger;
		navigator.geolocation.getCurrentPosition(function(position) {
			var longitude = position.coords.longitude;
			var latitude = position.coords.latitude;
			var latLong = new google.maps.LatLng(latitude, longitude);

			var mapOptions = {
				center: latLong,
				zoom: 13,
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};

			var map = new google.maps.Map(document.getElementById("maps"), mapOptions);

			var marker = new google.maps.Marker({
				position: latLong,
				map: map,
				title: 'Location'
			});
		}, function(error) {
			alert("the code is " + error.code + ". \n" + "message: " + error.message);
		});

	},
	handle_clear: function() {
		barcode_val.setValue("");
		mat_val.setValue("");
		desc_val.setValue("");
		crt_val.setValue("");
		image.setValue("");
		img.setSrc("");
	},

	draw: function() {

	},
	handle_scan: function() {
		//		this.load_scanned_val();
		setTimeout(function() {
			//        	if(barcode_result){
			this.load_scanned_val();
			//        	}
		}, 1000);
		cordova.plugins.barcodeScanner.scan(
			function(result) {
				barcode_result = result.text;
				barcode_val.setValue(result.text);
			},
			function(error) {
				alert("Scanning failed: " + error);
			}
		);
	},
	handle_camera: function(evt) {
		navigator.camera.getPicture(function(imageURL) {
			console.log("Entering cameraSuccess");
			image.setValue(imageURL);
			img.setSrc(imageURL);
			//                navigator.file.write('/sdcard/' +imageURL +'.jpg', "File Saved",
			//		    		            success(), fail());

			console.log("Leaving cameraSuccess");
		}, function(error) {
			alert("Camera failed: " + error);
		});
	},
	handleUploadComplete: function(oEvent) {
		var sResponse = oEvent.getParameter("response");
		if (sResponse) {
			var sMsg = "";
			var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);
			if (m[1] == "200") {
				sMsg = "Return Code: " + m[1] + "\n" + m[2], "SUCCESS", "Upload Success";
				oEvent.getSource().setValue("");
			} else {
				sMsg = "Return Code: " + m[1] + "\n" + m[2], "ERROR", "Upload Error";
			}

			sap.m.MessageToast.show(sMsg);
		}
	},
	load_scanned_val: function() {
		var barcodes = this.getView().getModel().oData.EquipmentSet;
		for (var i = 0; i < barcodes.length; i++) {
			if (barcodes[i].Equnr == barcode_result)

				mat_val.setValue(barcodes[i].Matnr);
			desc_val.setValue(barcodes[i].Eqktx);
			crt_val.setValue(barcodes[i].Erdat);
		}

		//	oModel.read("/EquipmentSet(Equnr='"+barcode_result+"')",  // Code to fetch from Actual OData Service
		//    		  
		//	          undefined,undefined,true,
		//	         function(oData, response)
		//	         {
		//		    	  mat_val.setValue(oData.Matnr);
		//		    	  desc_val.setValue(oData.Eqktx);
		//		    	  crt_val.setValue(oData.Erdat);
		//	         }
		//	      );
	},
	handleUploadPress: function(oEvent) {
		var oFileUploader = this.getView().byId("fileUploader");
		oFileUploader.upload();
	},

	handleNavButtonPress: function(evt) {
		this.router.navTo("Launchpad");
	},
	/**
	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	 * (NOT before the first rendering! onInit() is used for that one!).
	 * @memberOf view.Barcode
	 */
	//	onBeforeRendering: function() {
	//
	//	},

	/**
	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * @memberOf view.Barcode
	 */
	onAfterRendering: function() {
		//		  oModel.read("/EquipmentSet(Equnr='"+barcode_result+"')",
		//	    		  
		//		          undefined,undefined,true,
		//		         function(oData, response)
		//		         {
		////			    	  console.log("second call");
		//			    	  mat_val.setValue(oData.Matnr);
		//			    	  desc_val.setValue(oData.Eqktx);
		//			    	  crt_val.setValue(oData.Erdat);
		//		         }
		//		      );	

	},

	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * @memberOf view.Barcode
	 */
	//	onExit: function() {
	//
	//	}

});