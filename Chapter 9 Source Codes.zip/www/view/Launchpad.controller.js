jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.m.MessageToast");
sap.ui.controller("sap.ui.Cordova.app.view.Launchpad", {

	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf view.Empty
	 */
	onInit: function() {
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
	},
	handleNavButtonPress: function(evt) {
		this.router.navTo("Master");
	},
	handleNavPress: function(evt) {
		var sTile = evt.oSource.sId;
		if (sTile == "__tile0-__xmlview1--container-0") {
			this.router.navTo("Barcode");
		} else if (sTile == "__tile0-__xmlview1--container-1") {
			this.router.navTo("Asset_Tracker");
		} else if (sTile == "__tile0-__xmlview1--container-2") {
			this.router.navTo("Detail");
		} else {
			this.router.navTo("Detail");
		}
	},
	handleEditPress: function(evt) {
		var oTileContainer = this.getView().byId("container");
		var newValue = !oTileContainer.getEditable();
		oTileContainer.setEditable(newValue);
		evt.getSource().setText(newValue ? "Done" : "Edit");
	},

	handleTileDelete: function(evt) {
		var tile = evt.getParameter("tile");
		evt.getSource().removeTile(tile);
	},
	handleLogOff: function(oEvent) {

		// show confirmation dialog
		var bundle = this.getView().getModel("i18n").getResourceBundle();

		var oLayout = sap.ui.xmlfragment("sap.ui.Cordova.app.fragments.Layout_LogOff", this);

		// get the view and add the layout as a dependent. Since the layout is being put
		// into an aggregation any possible binding will be 'forwarded' to the layout.
		var oView = this.getView();
		oView.addDependent(oLayout);
		sap.m.MessageBox.show(oLayout, {
			icon: sap.m.MessageBox.Icon.WARNING,
			title: "Confirm Log Off",
			actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
			onClose: function(oAction) {
				if (oAction === sap.m.MessageBox.Action.YES) {
					var successMsg = bundle.getText("LogOffDialogSuccessMsg");
					var RouteRef = sap.ui.getCore().Route.Ref;
					RouteRef.navTo("Master");
					sap.m.MessageToast.show(successMsg);
				}
			},
			dialogId: "messageBoxId"
		});

	},
	/**
	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	 * (NOT before the first rendering! onInit() is used for that one!).
	 * @memberOf view.Empty
	 */
	//	onBeforeRendering: function() {
	//
	//	},

	/**
	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * @memberOf view.Empty
	 */
	onAfterRendering: function() {
		//		debugger;
		//var reset = "";
		//document.getElementById("__tile0-Empty--container-1-number").innerHTML = reset;
		//document.getElementById("__tile0-Empty--container-2-number").innerHTML = reset;
		//document.getElementById("__tile0-Empty--container-3-number").innerHTML = reset;
		//document.getElementById("__tile0-Empty--container-4-number").innerHTML = reset;
	},

	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * @memberOf view.Empty
	 */
	//	onExit: function() {
	//
	//	}

});