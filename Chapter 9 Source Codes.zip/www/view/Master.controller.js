jQuery.sap.require("sap.ui.Cordova.app.util.Formatter");
jQuery.sap.require("sap.ui.Cordova.app.util.Grouper");
jQuery.sap.require("sap.m.MessageBox");
var Uname1;
var Pswd1;
var delay;
var that;
jQuery.sap.require("sap.m.MessageToast");
sap.ui.controller("sap.ui.Cordova.app.view.Master", {
	_formFragments: {},
	onBeforeRendering: function() {
		var vbox = this.getView().byId("logon_vbox");
		vbox.addStyleClass(csmod);
	},
	_getFormFragment: function(sFragmentName) {
		var oFormFragment = this._formFragments[sFragmentName];

		if (!oFormFragment) {
			oFormFragment = sap.ui.xmlfragment(
				"sap.ui.Cordova.app.fragments" + sFragmentName
			);

		}
		return oFormFragment;
	},

	_showFormFragment: function(sFragmentName) {
		oForm = this._getFormFragment(sFragmentName);
		var oContainer = this.getView().byId("LoginContainer");
		oContainer.insertContent(oForm);

	},
	onInit: function(oEvent) {
		sap.ui.getCore().Route = new Object();
		sap.ui.getCore().Route.Ref = sap.ui.core.UIComponent.getRouterFor(this);
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		jQuery.sap.require("sap.ui.core.IconPool");

	},
	handleEmailPress: function(oEvent) {
		this._oPopover.close();
		jQuery.sap.require("sap.m.MessageToast");
		sap.m.MessageToast.show("An auto generated E-Mail with your details has been sent to scemobileapps@sce.com");
	},
	handleAlertMessageBoxPress: function(oEvent) {

		if (!this._oPopover) {
			this._oPopover = sap.ui.xmlfragment("sap.ui.Cordova.app.fragments.Custom_Message", this);
		}
		this._oPopover.setModel(this.getView().getModel());
		this._oPopover.openBy(oEvent.getSource());

	},

	handleLogin: function(evt) {
		var loginCheckFlag = 0;
		var context = evt.getSource().getBindingContext();
		var uname = this.getView().byId("userName").getValue();
		var pswd = this.getView().byId("password").getValue();
		//		debugger;
		if ((uname != "USER" && uname != "user") || (pswd != "user123")) {
			loginCheckFlag++;
		}
		//		debugger;
		if (loginCheckFlag != 0) {
			console.log("1");
			this.handleAlertMessageBoxPress(evt);
		} else {
			console.log(uname);
			this.router.navTo("Launchpad");

		}

	},
	handleChangePswd: function(evt) {
		var context = evt.getSource().getBindingContext();
		this.router.navTo("ChangePswd");
	}

});