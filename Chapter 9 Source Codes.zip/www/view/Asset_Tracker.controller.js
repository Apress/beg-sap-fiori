sap.ui.controller("sap.ui.Cordova.app.view.Asset_Tracker", {

	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf view.Asset_Tracker
	 */
	onInit: function() {
		sap.ui.getCore().Map = new Object();
		sap.ui.getCore().Map.Ref = this.getView();
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		select_cntrl = this.getView().byId("select");
		mat_val = this.getView().byId("material_val");
		desc_val = this.getView().byId("description_val");
		crt_val = this.getView().byId("crt_on_val");
		image = this.getView().byId("image_url");
		img = this.getView().byId("img");
	},
	handleNavButtonPress: function(evt) {
		this.router.navTo("Launchpad");
	},
	handle_locate_all: function(evt) {
		var records = this.getView().getModel().oData.GeolocSet;
		var bounds = new google.maps.LatLngBounds();

		navigator.geolocation.getCurrentPosition(function(position) {
			var mapOptions = {
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};
			// Info Window Content
			var infoWindowContent = [
				['<div class="info_content">' +
					'<h3>OST Asset</h3>' +
					'<p>Property Of Open Source Tech' + '</div>'
				],
				['<div class="info_content">' +
					'<h3>OST Asset</h3>' +
					'<p>Property Of Open Source Tech' + '</div>'
				],
				['<div class="info_content">' +
					'<h3>OST Asset</h3>' +
					'<p>Property Of Open Source Tech</p>' +
					'</div>'
				]
			];
			// Display multiple markers on a map
			var infoWindow = new google.maps.InfoWindow(),
				marker_new, i;
			var MapRef = sap.ui.getCore().Map.Ref;
			var map_new = new google.maps.Map(document.getElementById(MapRef.byId("maps_new").sId), mapOptions);
			map_new.setTilt(45);
			for (i = 0; i < records.length; i++) {
				//				debugger;
				var position = new google.maps.LatLng(records[i].Longitude, records[i].Latitude);
				bounds.extend(position);
				marker_new = new google.maps.Marker({
					position: position,
					map: map_new,
					title: 'Location' + i
				});
				// Allow each marker to have an info window    
				google.maps.event.addListener(marker_new, 'click', (function(marker, i) {
					return function() {
						infoWindow.setContent(infoWindowContent[i][0]);
						infoWindow.open(map_new, marker);
					}
				})(marker_new, i));

				// Automatically center the map fitting all markers on the screen
				map_new.fitBounds(bounds);
			}
		});

		//		oModel.read("/GeolocSet",
		//	    		  
		//		          undefined,undefined,true,
		//		         function(oData, response)
		//		         {
		//			
		//			var bounds = new google.maps.LatLngBounds();
		//	    	  
		//			  		navigator.geolocation.getCurrentPosition(function(position){			 
		//				        var mapOptions = {
		//				            mapTypeId: google.maps.MapTypeId.ROADMAP
		//				        };
		//				     // Info Window Content
		//				        var infoWindowContent = [
		//				            ['<div class="info_content">' +
		//				            '<h3>OST Asset</h3>' +
		//				            '<p>Property Of Open Source Tech' +        '</div>'],
		//				            ['<div class="info_content">' +
		//					            '<h3>OST Asset</h3>' +
		//					            '<p>Property Of Open Source Tech' +        '</div>'],
		//				            ['<div class="info_content">' +
		//				            '<h3>OST Asset</h3>' +
		//				            '<p>Property Of Open Source Tech</p>' +
		//				            '</div>']
		//				        ];				        
		//				        // Display multiple markers on a map
		//				        var infoWindow = new google.maps.InfoWindow(), marker_new, i;				 
		//				        var map_new = new google.maps.Map(document.getElementById("__xmlview2--maps_new"), mapOptions);
		//				        map_new.setTilt(45);
		//				        for( i = 0; i < oData.results.length; i++ ) {
		////							debugger;
		//							 var position = new google.maps.LatLng(oData.results[i].Longitude,oData.results[i].Latitude );
		//						        bounds.extend(position);
		//						        marker_new = new google.maps.Marker({
		//						            position: position,
		//						            map: map_new,
		//						            title:'Location'+i});
		//						        // Allow each marker to have an info window    
		//						        google.maps.event.addListener(marker_new, 'click', (function(marker, i) {
		//						            return function() {
		//						                infoWindow.setContent(infoWindowContent[i][0]);
		//						                infoWindow.open(map_new, marker);
		//						            }
		//						        })(marker_new, i));
		//
		//						        // Automatically center the map fitting all markers on the screen
		//						        map_new.fitBounds(bounds);						        
		//						}					
		//				    }, function(error){
		//				        alert("the code is " + error.code + ". \n" + "message: " + error.message);
		//				    });			    	  
		//			    	  
		//		         }
		//		      );

	},
	handle_select_change: function(evt) {

		equinr_val = select_cntrl.getSelectedKey();
		var records = this.getView().getModel().oData.GeolocSet;
		for (var i = 0; i < records.length; i++) {
			if (records[i].Equnr == equinr_val.toString()) {
				var Geolocate = records[i].Equnr;
				var longitude_new = records[i].Latitude;
				var latitude_new = records[i].Longitude;
				mat_val.setValue(records[i].Matnr);
				desc_val.setValue(records[i].Eqktx);
				crt_val.setValue(records[i].Erdat);
			}
		}
		if (Geolocate) {
			navigator.geolocation.getCurrentPosition(function(position) {
				var latLong_new = new google.maps.LatLng(latitude_new, longitude_new);

				var mapOptions = {
					center: latLong_new,
					zoom: 13,
					mapTypeId: google.maps.MapTypeId.ROADMAP
				};
				var MapRef = sap.ui.getCore().Map.Ref;
				var map_new = new google.maps.Map(document.getElementById(MapRef.byId("maps_new").sId), mapOptions);

				var marker_new = new google.maps.Marker({
					position: latLong_new,
					map: map_new,
					title: 'Location'
				});
			});
		}
		//		oModel.read("/GeolocSet(Equnr='0000000000"+equinr_val+"')",  //Function import Call from OData, to know about Funtion Imports check this link http://scn.sap.com/docs/DOC-55336
		//	    		  
		//		          undefined,undefined,true,
		//		         function(oData, response)
		//		         {
		////			    	  console.log("second call");
		//			    	  mat_val.setValue(oData.Matnr);
		//			    	  desc_val.setValue(oData.Eqktx);
		//			    	  crt_val.setValue(oData.Erdat);
		//			    	  
		//			  		navigator.geolocation.getCurrentPosition(function(position){
		//				        var longitude_new = oData.Latitude;
		//				        var latitude_new = oData.Longitude;
		//				        var latLong_new = new google.maps.LatLng(latitude_new, longitude_new);
		//				 
		//				        var mapOptions = {
		//				            center: latLong_new,
		//				            zoom: 13,
		//				            mapTypeId: google.maps.MapTypeId.ROADMAP
		//				        };
		//				 
		//				        var map_new = new google.maps.Map(document.getElementById("__xmlview2--maps_new"), mapOptions);
		//					
		//				        var marker_new = new google.maps.Marker({
		//				              position: latLong_new,
		//				              map: map_new,
		//				              title: 'Location'
		//				          });
		//				    }, function(error){
		//				        alert("the code is " + error.code + ". \n" + "message: " + error.message);
		//				    });			    	  
		//			    	  
		//		         }
		//		      );		
	},
	handle_location: function() {
		//		debugger;
		//		navigator.geolocation.getCurrentPosition(function(position){
		//	        var longitude = position.coords.longitude;
		//	        var latitude = position.coords.latitude;
		//	        var latLong = new google.maps.LatLng(latitude, longitude);
		//	 
		//	        var mapOptions = {
		//	            center: latLong,
		//	            zoom: 13,
		//	            mapTypeId: google.maps.MapTypeId.ROADMAP
		//	        };
		//	 
		//	        var map = new google.maps.Map(document.getElementById("Asset_Tracker--maps"), mapOptions);
		//		
		//	        var marker = new google.maps.Marker({
		//	              position: latLong,
		//	              map: map,
		//	              title: 'Location'
		//	          });
		//	    }, function(error){
		//	        alert("the code is " + error.code + ". \n" + "message: " + error.message);
		//	    });

	},
	/**
	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	 * (NOT before the first rendering! onInit() is used for that one!).
	 * @memberOf view.Asset_Tracker
	 */
	//	onBeforeRendering: function() {
	//
	//	},

	/**
	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * @memberOf view.Asset_Tracker
	 */
	//	onAfterRendering: function() {
	//
	//	},

	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * @memberOf view.Asset_Tracker
	 */
	//	onExit: function() {
	//
	//	}

});