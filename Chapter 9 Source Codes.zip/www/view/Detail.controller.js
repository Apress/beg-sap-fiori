jQuery.sap.require("sap.ui.Cordova.app.util.Formatter");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.m.MessageToast");
var global_data;
var global_data1;
var global_that;
sap.ui.controller("sap.ui.Cordova.app.view.Detail", {

	handleNavButtonPress: function(evt) {
		this.router.navTo("Launchpad");
	},
	onInit: function() {
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
	},
	handleListItemPress: function(evt) {
		//		console.log("itempress");
		var context = evt.getSource().getBindingContext().sPath;
		sViewId = context.substring(context.lastIndexOf("/") + 1);
		this.router.navTo("Item_Detail", {
			data: sViewId
		});
	},

	handleSearch: function(evt) {

		// create model filter
		var filters = [];
		var query = evt.getParameter("query");
		if (query && query.length > 0) {
			var filter = new sap.ui.model.Filter("Username", sap.ui.model.FilterOperator.Contains, query);
			filters.push(filter);
		}

		// update list binding
		var list = this.getView().byId("list");
		var binding = list.getBinding("items");
		binding.filter(filters);
	},

	handleListSelect: function(evt) {
		var context = evt.getParameter("listItem").getBindingContext().sPath;
		sViewId = context.substring(context.lastIndexOf("/") + 1);
		this.router.navTo("Item_Detail", {
			data: sViewId
		});

	},

	handleGroup: function(evt) {

		// compute sorters
		var sorters = [];
		var item = evt.getParameter("selectedItem");
		var key = (item) ? item.getKey() : null;
		if ("days_count" === key || "DayStatus" === key) {
			sap.ui.Cordova.app.util.Grouper.bundle = this.getView().getModel("i18n").getResourceBundle();
			var grouper = sap.ui.Cordova.app.util.Grouper[key];
			sorters.push(new sap.ui.model.Sorter(key, true, grouper));
		}

		// update binding
		var list = this.getView().byId("list");
		var oBinding = list.getBinding("items");
		oBinding.sort(sorters);
	}
});