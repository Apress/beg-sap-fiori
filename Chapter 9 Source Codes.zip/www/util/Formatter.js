jQuery.sap.declare("sap.ui.Cordova.app.util.Formatter");

jQuery.sap.require("sap.ui.core.format.DateFormat");

sap.ui.Cordova.app.util.Formatter = {
	
	_statusStateMap : {
		"P" : "Success",
		"N" : "Warning"
	},

	statusText :  function (value) {
//		debugger;
		var bundle = this.getModel("i18n").getResourceBundle();
		return bundle.getText("StatusText" + value, "?");
	},
	statusType :  function (value) {
	
		if (value == "")
			{
			value = " ";
			}
		return value;
	},
	imageText :  function (value) {
		var bundle = this.getModel("i18n").getResourceBundle();
		if (value=="Zoe John")
			{
		value = "./images/zoe.jpg";
			}
		else if (value=="Ryan Mcarthy")
		{
			value = "./images/ken.jpg";
		}
		else if (value=="Drake Johns")
		{
			value = "./images/john.jpg";
		}
		else
		{
			value = "./images/male.png";
		}
		return value;
	},
	Login :  function (value) {
		var bundle = this.getModel("i18n").getResourceBundle();
//		debugger;
		if (value=="Zoe John")
			{
		value = "./images/zoe.jpg";
			}
		else 
		{
			value = "./images/ken.jpg";
		}
		return value;
	},	
	
	statusState :  function (value) {
		var map = sap.ui.Cordova.app.util.Formatter._statusStateMap;
		return (value && map[value]) ? map[value] : "None";
	},
	
	date : function (value) {
		if (value) {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "yyyy-MM-dd"}); 
			return oDateFormat.format(new Date(value));
		} else {
			return value;
		}
	},
	
	quantity :  function (value) {
		try {
			return (value) ? parseFloat(value).toFixed(0) : value;
		} catch (err) {
			return "Not-A-Number";
		}
	}
};