jQuery.sap.declare("sap.ui.Cordova.app.Component");
var csmod;
var oModel;
sap.ui.core.UIComponent.extend("sap.ui.Cordova.app.Component", {
	metadata: {
		"abstract": true,
		version: "1.0",
		includes: [
			"css/custom.css",
			"/cordova.js",
			"js/index.js",

		],
		routing: {

			config: {
				viewType: "XML",
				viewPath: "sap.ui.Cordova.app.view",
				clearTarget: false,
				transition: "slide",
				targetControl: "App",
				targetAggregation: "pages"
			},
			routes: [{
					pattern: "",
					name: "default",
					view: "Master",
				}, {
					pattern: "launchpad",
					name: "Launchpad",
					view: "Launchpad",
				}, {
					pattern: "asset",
					name: "Asset_Tracker",
					view: "Asset_Tracker",
				}, {
					pattern: "barcode",
					name: "Barcode",
					view: "Barcode",
				}, {
					pattern: "password",
					name: "ChangePswd",
					view: "ChangePswd",
				}, {
					pattern: "itemdetail/{data}",
					name: "Item_Detail",
					view: "Item_Detail",
				}, {
					pattern: "detail",
					name: "Detail",
					view: "Detail",
				}

			]

		}

	},
	init: function() {
		jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
		jQuery.sap.require("sap.ui.core.routing.HashChanger");

		//call createContent
		sap.ui.core.UIComponent.prototype.init.apply(this, arguments);

		this._router = this.getRouter();

		//initlialize the router
		this._routeHandler = new sap.m.routing.RouteMatchedHandler(this._router);
		this._router.initialize();

	},
	createContent: function() {

		// create root view
		var oView = sap.ui.view({
			id: "App",
			viewName: "sap.ui.Cordova.app.view.App",
			type: "XML",
			viewData: {
				component: this
			}
		});

		// set i18n model
		var i18nModel = new sap.ui.model.resource.ResourceModel({
			bundleUrl: "i18n/messageBundle.properties"
		});
		oView.setModel(i18nModel, "i18n");

		//		// Using OData model to connect against a real service
		//		var url = "http://gatewayurl:proxy/sap/opu/odata/sap/Odata_Service_Name/";
		//		oModel = new sap.ui.model.odata.ODataModel(url, true, "username", "password");
		//		oView.setModel(oModel);

		// Using a local model for offline development
		var oModel = new sap.ui.model.json.JSONModel("model/data.json");
		oView.setModel(oModel);

		// set device model
		var deviceModel = new sap.ui.model.json.JSONModel({
			classmode: (sap.ui.Device.system.phone) ? csmod = "center" : csmod = "center1",
			isPhone: sap.ui.Device.system.phone,
			listMode: (sap.ui.Device.system.phone) ? "None" : "SingleSelectMaster",
			listItemType: (sap.ui.Device.system.phone) ? "Active" : "Inactive"
		});
		deviceModel.setDefaultBindingMode("OneWay");
		oView.setModel(deviceModel, "device");

		// done
		return oView;
	}
});